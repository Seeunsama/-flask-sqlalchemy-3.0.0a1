from __future__ import annotations

import typing as t

import pytest
import sqlalchemy as sa
from flask import Flask
from werkzeug.exceptions import NotFound

from flask_sqlalchemy import SQLAlchemy
from flask_sqlalchemy.query import Query


@pytest.mark.usefixtures("app_ctx")
def test_get_or_404(db: SQLAlchemy, Todo: t.Any) -> None:
    item = Todo()
    db.session.add(item)
    db.session.commit()
    assert Todo.query.get_or_404(1) is item

    with pytest.raises(NotFound):
        Todo.query.get_or_404(2)


@pytest.mark.usefixtures("app_ctx")
def test_first_or_404(db: SQLAlchemy, Todo: t.Any) -> None:
    db.session.add(Todo(title="a"))
    db.session.commit()
    assert Todo.query.filter_by(title="a").first_or_404().title == "a"

    with pytest.raises(NotFound):
        Todo.query.filter_by(title="b").first_or_404()


@pytest.mark.usefixtures("app_ctx")
def test_one_or_404(db: SQLAlchemy, Todo: t.Any) -> None:
    db.session.add(Todo(title="a"))
    db.session.add(Todo(title="b"))
    db.session.add(Todo(title="b"))
    db.session.commit()
    assert Todo.query.filter_by(title="a").one_or_404().title == "a"

    with pytest.raises(NotFound):
        # MultipleResultsFound
        Todo.query.filter_by(title="b").one_or_404()

    with pytest.raises(NotFound):
        # NoResultFound
        Todo.query.filter_by(title="c").one_or_404()


@pytest.mark.usefixtures("app_ctx")
def test_default_query_class(db: SQLAlchemy) -> None:
    class Parent(db.Model):
        id = sa.Column(sa.Integer, primary_key=True)
        children1 = db.relationship("Child", backref="parent1", lazy="dynamic")

    class Child(db.Model):
        id = sa.Column(sa.Integer, primary_key=True)
        parent_id = sa.Column(sa.ForeignKey(Parent.id))
        parent2 = db.relationship(
            Parent,
            backref=db.backref("children2", lazy="dynamic", viewonly=True),
            viewonly=True,
        )

    p = Parent()
    assert type(Parent.query) is Query
    assert isinstance(p.children1, Query)
    assert isinstance(p.children2, Query)
    assert isinstance(db.session.query(Child), Query)


@pytest.mark.usefixtures("app_ctx")
def test_custom_query_class(app: Flask) -> None:
    class CustomQuery(Query):
        pass

    db = SQLAlchemy(app, query_class=CustomQuery)

    class Parent(db.Model):
        id = sa.Column(sa.Integer, primary_key=True)
        children1 = db.relationship("Child", backref="parent1", lazy="dynamic")

    class Child(db.Model):
        id = sa.Column(sa.Integer, primary_key=True)
        parent_id = sa.Column(sa.ForeignKey(Parent.id))
        parent2 = db.relationship(
            Parent,
            backref=db.backref("children2", lazy="dynamic", viewonly=True),
            viewonly=True,
        )

    p = Parent()
    assert type(Parent.query) is CustomQuery
    assert isinstance(p.children1, CustomQuery)
    assert isinstance(p.children2, CustomQuery)
    assert isinstance(db.session.query(Child), CustomQuery)
